import java.util.Scanner;

public class ItemCost {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the item name: ");
        String itemName = input.nextLine();

        System.out.print("Enter the quantity: ");
        int quantity = input.nextInt();

        System.out.print("Enter the cost per item: ");
        double unitCost = input.nextDouble();

        if (quantity < 0 || unitCost < 0) {
            System.out.println("Quantity and cost cannot be negative.");
        } else {
            double totalCost = quantity * unitCost;
            System.out.printf("Total cost of %s: %.2f%n", itemName, totalCost);
        }

        input.close();
    }
}
