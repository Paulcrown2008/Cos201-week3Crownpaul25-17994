# COS 201 – Computer Programming I
## Week 3 Java Programs

**Student Name:** Paul Crown Chinonso  
**Matriculation Number:** 25/17994  
**Programme:** Computer Science  

### Programs included
1. `SimpleCalculator.java` – performs addition, subtraction, multiplication and division.
2. `AverageCalculator.java` – calculates the average of three numbers.
3. `ItemCost.java` – calculates total item cost from quantity and unit price.

### Requirements
- Java Development Kit (JDK) installed.
- A terminal/command prompt.

### How to compile and run
Open a terminal in this folder and compile each program:

```bash
javac SimpleCalculator.java
java SimpleCalculator
```

```bash
javac AverageCalculator.java
java AverageCalculator
```

```bash
javac ItemCost.java
java ItemCost
```

Each program prompts the user for the required input and displays the result.
